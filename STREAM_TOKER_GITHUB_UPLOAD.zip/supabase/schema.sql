create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default '',
  avatar_url text,
  followers_count bigint not null default 0,
  following_count bigint not null default 0,
  likes_count bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_path text not null,
  caption text not null default '',
  likes_count bigint not null default 0,
  comments_count bigint not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete set null,
  gift_type text not null,
  coins integer not null check (coins > 0),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.follows enable row level security;
alter table public.messages enable row level security;
alter table public.gifts enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "videos readable" on public.videos for select using (true);
create policy "own video insert" on public.videos for insert with check (auth.uid() = user_id);
create policy "own video update" on public.videos for update using (auth.uid() = user_id);
create policy "own video delete" on public.videos for delete using (auth.uid() = user_id);

create policy "follows readable" on public.follows for select using (true);
create policy "own follow insert" on public.follows for insert with check (auth.uid() = follower_id);
create policy "own follow delete" on public.follows for delete using (auth.uid() = follower_id);

create policy "own messages read" on public.messages for select using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "own messages insert" on public.messages for insert with check (auth.uid() = sender_id);

create policy "gifts readable to participants" on public.gifts for select using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "gift sender insert" on public.gifts for insert with check (auth.uid() = sender_id);

insert into storage.buckets (id, name, public) values ('videos','videos',true) on conflict (id) do nothing;
create policy "video objects public read" on storage.objects for select using (bucket_id = 'videos');
create policy "video objects own upload" on storage.objects for insert with check (bucket_id = 'videos' and auth.uid()::text = (storage.foldername(name))[1]);

-- Realtime: messages are published so clients can subscribe to new chat messages.
alter publication supabase_realtime add table public.messages;
