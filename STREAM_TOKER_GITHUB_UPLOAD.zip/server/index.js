import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createClient } from '@supabase/supabase-js';

const app = express();
app.use(cors());
app.use(express.json());
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function requireUser(req,res,next){
  const auth=req.headers.authorization||'';
  const token=auth.startsWith('Bearer ')?auth.slice(7):null;
  if(!token) return res.status(401).json({error:'Missing bearer token'});
  const {data:{user},error}=await supabase.auth.getUser(token);
  if(error||!user) return res.status(401).json({error:'Invalid session'});
  req.user=user; next();
}

app.get('/health',(req,res)=>res.json({ok:true,service:'stream-toker-server'}));
app.post('/profile',requireUser,async(req,res)=>{
  const {username,display_name}=req.body;
  const {data,error}=await supabase.from('profiles').upsert({id:req.user.id,username,display_name}).select().single();
  if(error) return res.status(400).json({error:error.message}); res.json(data);
});
app.get('/feed',async(req,res)=>{
  const {data,error}=await supabase.from('videos').select('id,user_id,video_path,caption,likes_count,comments_count,created_at,profiles(username,display_name,avatar_url,followers_count)').order('created_at',{ascending:false}).limit(30);
  if(error) return res.status(400).json({error:error.message}); res.json(data||[]);
});
app.post('/gift',requireUser,async(req,res)=>{
  const {receiver_id,video_id,gift_type,coins}=req.body;
  const {data,error}=await supabase.from('gifts').insert({sender_id:req.user.id,receiver_id,video_id,gift_type,coins}).select().single();
  if(error) return res.status(400).json({error:error.message}); res.json(data);
});
app.listen(process.env.PORT||8787,()=>console.log(`Stream Toker server listening on ${process.env.PORT||8787}`));
