# Stream Toker — ready for your public Supabase key

This ZIP is prepared so you only need to enter one account value.

## The only thing you change
Open the `.env` file and replace:

`PASTE_YOUR_PUBLIC_SUPABASE_KEY_HERE`

with the **public anon/publishable key** from your Stream Toker Supabase project. Do not enter a service-role/secret key.

The Supabase project URL is already set to:
`https://igztzktvzhsuddaanxnp.supabase.co`

## After entering the key
Install the dependencies and run the Expo app. If the database schema has not already been installed, run `supabase_schema.sql` once in the Supabase SQL Editor.

## Security
The mobile app must contain only the public anon/publishable key. Never put the Supabase service-role/secret key in this ZIP or in the mobile app.

## Important
This build connects the app's existing auth/profile/post/video/like/follow/message flows to Supabase. Features such as real live video streaming, video storage delivery, payments/coins, moderation, and creator payouts still require their actual production services/configuration; they are not safely faked as “live.”
