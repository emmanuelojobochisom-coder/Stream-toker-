-- Stream Toker — Supabase database schema
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  bio text,
  followers_count bigint not null default 0,
  following_count bigint not null default 0,
  likes_count bigint not null default 0,
  coins_balance bigint not null default 0,
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text,
  caption text,
  thumbnail_url text,
  likes_count bigint not null default 0,
  comments_count bigint not null default 0,
  views_count bigint not null default 0,
  status text not null default 'published'
    check (status in ('draft','published','blocked','deleted')),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.video_likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete set null,
  gift_name text not null,
  gift_emoji text,
  coin_value bigint not null check (coin_value > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.creator_reward_rules (
  id uuid primary key default gen_random_uuid(),
  follower_threshold bigint not null default 4000000,
  monthly_amount_kobo bigint not null default 5900000,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.creator_rewards (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  amount_kobo bigint not null check (amount_kobo > 0),
  status text not null default 'pending'
    check (status in ('pending','approved','paid','rejected')),
  period_start date,
  period_end date,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete set null,
  video_id uuid references public.videos(id) on delete set null,
  reason text not null,
  details text,
  status text not null default 'open'
    check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create index if not exists videos_creator_idx on public.videos(creator_id, created_at desc);
create index if not exists comments_video_idx on public.comments(video_id, created_at desc);
create index if not exists messages_receiver_idx on public.messages(receiver_id, created_at desc);
create index if not exists messages_sender_idx on public.messages(sender_id, created_at desc);
create index if not exists gifts_receiver_idx on public.gifts(receiver_id, created_at desc);

-- Automatically create a profile after a user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', 'user_' || substr(new.id::text, 1, 8)),
    coalesce(new.raw_user_meta_data->>'display_name', 'New User')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Keep updated_at current.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at
before update on public.profiles
for each row execute procedure public.set_updated_at();

-- Enable RLS.
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.follows enable row level security;
alter table public.video_likes enable row level security;
alter table public.comments enable row level security;
alter table public.gifts enable row level security;
alter table public.messages enable row level security;
alter table public.creator_reward_rules enable row level security;
alter table public.creator_rewards enable row level security;
alter table public.reports enable row level security;

-- Profiles
drop policy if exists "profiles are publicly readable" on public.profiles;
create policy "profiles are publicly readable"
on public.profiles for select
using (true);

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

-- Videos
drop policy if exists "published videos are readable" on public.videos;
create policy "published videos are readable"
on public.videos for select
using (status = 'published' or creator_id = auth.uid());

drop policy if exists "users create own videos" on public.videos;
create policy "users create own videos"
on public.videos for insert
with check (creator_id = auth.uid());

drop policy if exists "users update own videos" on public.videos;
create policy "users update own videos"
on public.videos for update
using (creator_id = auth.uid())
with check (creator_id = auth.uid());

drop policy if exists "users delete own videos" on public.videos;
create policy "users delete own videos"
on public.videos for delete
using (creator_id = auth.uid());

-- Follows
drop policy if exists "follows readable" on public.follows;
create policy "follows readable"
on public.follows for select
using (true);

drop policy if exists "users follow from own account" on public.follows;
create policy "users follow from own account"
on public.follows for insert
with check (follower_id = auth.uid());

drop policy if exists "users unfollow from own account" on public.follows;
create policy "users unfollow from own account"
on public.follows for delete
using (follower_id = auth.uid());

-- Likes
drop policy if exists "likes readable" on public.video_likes;
create policy "likes readable"
on public.video_likes for select
using (true);

drop policy if exists "users like as themselves" on public.video_likes;
create policy "users like as themselves"
on public.video_likes for insert
with check (user_id = auth.uid());

drop policy if exists "users remove own likes" on public.video_likes;
create policy "users remove own likes"
on public.video_likes for delete
using (user_id = auth.uid());

-- Comments
drop policy if exists "comments readable" on public.comments;
create policy "comments readable"
on public.comments for select
using (true);

drop policy if exists "users create own comments" on public.comments;
create policy "users create own comments"
on public.comments for insert
with check (user_id = auth.uid());

drop policy if exists "users delete own comments" on public.comments;
create policy "users delete own comments"
on public.comments for delete
using (user_id = auth.uid());

-- Messages
drop policy if exists "participants read messages" on public.messages;
create policy "participants read messages"
on public.messages for select
using (sender_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists "users send messages" on public.messages;
create policy "users send messages"
on public.messages for insert
with check (sender_id = auth.uid());

drop policy if exists "receivers update messages" on public.messages;
create policy "receivers update messages"
on public.messages for update
using (receiver_id = auth.uid())
with check (receiver_id = auth.uid());

-- Gifts: users can see gifts they sent or received; sending must be done as the sender.
drop policy if exists "gift participants read gifts" on public.gifts;
create policy "gift participants read gifts"
on public.gifts for select
using (sender_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists "users send gifts" on public.gifts;
create policy "users send gifts"
on public.gifts for insert
with check (sender_id = auth.uid());

-- Rewards and reward rules are intentionally restricted.
drop policy if exists "reward rules readable" on public.creator_reward_rules;
create policy "reward rules readable"
on public.creator_reward_rules for select
using (true);

drop policy if exists "creators read own rewards" on public.creator_rewards;
create policy "creators read own rewards"
on public.creator_rewards for select
using (creator_id = auth.uid());

-- Reports: users submit and read their own reports.
drop policy if exists "users create reports" on public.reports;
create policy "users create reports"
on public.reports for insert
with check (reporter_id = auth.uid());

drop policy if exists "users read own reports" on public.reports;
create policy "users read own reports"
on public.reports for select
using (reporter_id = auth.uid());

-- Initial owner-configured reward rule.
insert into public.creator_reward_rules (follower_threshold, monthly_amount_kobo, active)
select 4000000, 5900000, true
where not exists (select 1 from public.creator_reward_rules);

-- Storage buckets for video and avatar files.
insert into storage.buckets (id, name, public)
values
  ('videos', 'videos', true),
  ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Public read access for uploaded media.
drop policy if exists "public read videos" on storage.objects;
create policy "public read videos"
on storage.objects for select
using (bucket_id in ('videos', 'avatars'));

-- Authenticated users can upload into their own folder.
drop policy if exists "users upload own media" on storage.objects;
create policy "users upload own media"
on storage.objects for insert to authenticated
with check (
  bucket_id in ('videos', 'avatars')
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Authenticated users can update/delete their own media.
drop policy if exists "users manage own media" on storage.objects;
create policy "users manage own media"
on storage.objects for delete to authenticated
using (
  bucket_id in ('videos', 'avatars')
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "users update own media" on storage.objects;
create policy "users update own media"
on storage.objects for update to authenticated
using (
  bucket_id in ('videos', 'avatars')
  and (storage.foldername(name))[1] = auth.uid()::text
);
